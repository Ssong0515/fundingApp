package bitc.fullstack405.fun_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class funspringTests {

    @Test
    void contextLoads() {
    }

}
