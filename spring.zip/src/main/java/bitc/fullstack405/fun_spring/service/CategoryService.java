package bitc.fullstack405.fun_spring.service;

import bitc.fullstack405.fun_spring.entity.CategoryEntity;

public interface CategoryService {
    CategoryEntity getCategory(int categoryId);
}
